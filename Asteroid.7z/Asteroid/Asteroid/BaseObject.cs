﻿using System;
using System.Drawing;
namespace MyGame
{
    abstract class BaseObject
    {
        protected Point Pos;
        protected Point Dir;
        protected Size Size;
        public BaseObject(Point pos, Point dir, Size size)
        {
            try
            {
                if (pos.X > 1000 || pos.Y > 1000 || dir.X > 100 || dir.Y > 100 || size.Height < 0 || size.Width < 0) throw new GameObjectException("Недопустимые параметры объекта");
                Pos = pos;
                Dir = dir;//направление движения
                Size = size;
            }
            catch (GameObjectException e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);
            }
        }

        public virtual void Draw()
        {
            Game.Buffer.Graphics.DrawEllipse(Pens.White, Pos.X, Pos.Y, Size.Width, Size.Height);
        }
        public abstract void Update();
        //{
        //    Pos.X = Pos.X + Dir.X;
        //    Pos.Y = Pos.Y + Dir.Y;
        //    if (Pos.X < 0) Dir.X = -Dir.X;
        //    if (Pos.X > Game.Width) Dir.X = -Dir.X;
        //    if (Pos.Y < 0) Dir.Y = -Dir.Y;
        //    if (Pos.Y > Game.Height) Dir.Y = -Dir.Y;
        //}
    }
}