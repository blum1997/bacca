﻿using System.Drawing;
namespace MyGame
{
    class ImageStar : BaseObject
    {
        protected Image Img;
        public ImageStar(Point pos, Point dir, Size size, Image img) : base(pos, dir, size)
        {
            Img = img;
        }
        public override void Draw()
        {
            Game.Buffer.Graphics.DrawImage(Img, Pos);
        }
        public override void Update()
        {
            Pos.X = Pos.X - Dir.X;
            if (Pos.X < 0) Pos.X = Game.Width + Img.Size.Width;
        }
    }
}