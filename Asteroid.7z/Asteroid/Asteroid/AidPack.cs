﻿using System.Drawing;

namespace MyGame
{
    class AidPack : Shot
    {
        public AidPack(Point pos, Image img) : base(pos, img)
        {
            Needtodraw = true;
            
        }
        public override void Draw()
        {
            Game.Buffer.Graphics.DrawImage(Img, Pos);
        }
        public override void Update()
        {
            Pos.X = Pos.X - 15;
            if (Pos.X < 0) { NeedToDraw = false; NeedToUpdate = false; }
        }

        //public bool NeedToDraw
        //{
        //    get { return Needtodraw; }
        //    set { Needtodraw = value; }
        //}

        //public Point Position
        //{
        //    get { return Pos; }
        //}
    }
}
