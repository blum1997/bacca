﻿using System;

namespace MyGame
{
    class HeightWidthException : Exception
    {
        public HeightWidthException(string msg) : base(msg)
        {

        }

    }
}