﻿using System.Drawing;
using System;
namespace MyGame
{
    class Shot : IDisposable
    {
        protected Point Pos;
        protected Image Img;
        protected bool NeedToDraw;
        protected bool NeedToUpdate;
        public bool Needtodraw
        {
            set { NeedToDraw = value; }
            get { return NeedToDraw; }
        }
        public bool Needtoupdate
        {
            set { NeedToUpdate = value;}
            get { return NeedToUpdate; }
        }

        public Point Position
        {
            get { return Pos; }
        }
        public Shot(Point pos, Image img)
        {
            Pos = pos;
            Pos.Y += 27;
            Img = img;
            NeedToDraw = true;
            NeedToUpdate = true;
        }
        public virtual void Draw()
        {
            Game.Buffer.Graphics.DrawImage(Img,Pos);        
        }
        public virtual void Update()
        {
            Pos.X = Pos.X + 10;
            if (Pos.X > Game.Width) { NeedToDraw = false; NeedToUpdate = false; }
        }

        public void Dispose()
        {
            Img = null;
            //GC.Collect() ;
        }
    }
}