﻿using System;
using System.Windows.Forms;
using MyGame;

namespace Asteroid
{
    class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        public static Form form = new Form();
        public static TextBox width = new TextBox();
        public static TextBox height = new TextBox();
        public static Button start = new Button();
        static void Main()
        {
            form.Width = 800;
            form.Height = 600;
            #region Создание элементов меню
           
            width.Text = "800";
            width.Width = 100;
            width.Height = 50;
            width.Top = 100;
            width.Left = 50;
            form.Controls.Add(width);
           
            height.Text = "600";
            height.Width = 100;
            height.Height = 50;
            height.Top = 200;
            height.Left = 50;
            form.Controls.Add(height);
           
            start.Text = "Start";
            start.Width = 100;
            start.Height = 50;
            start.Top = 300;
            start.Left = 50;
            form.Controls.Add(start);
            start.Click += start_click;
            #endregion
            form.Show();
            Application.Run(form);
        }

        private static void start_click(object sender, EventArgs k)
        {
            try
            {
                if (Convert.ToInt32(height.Text) > 1000 || Convert.ToInt32(width.Text) > 1000 || Convert.ToInt32(height.Text) <= 0 || Convert.ToInt32(width.Text) <= 0) throw new HeightWidthException("Недопустимые значения ширины или высоты");
                Form form1 = new Form();

                form1.FormClosed += Form1_FormClosed;// при закрытии формы с игрой выходим из приложения, иначе остается открытым поток и происходит ошибка в обработке буфера.

                form1.Width = Convert.ToInt32(width.Text);
                form1.Height = Convert.ToInt32(height.Text);
                Game.Init(form1);
                Game.Draw();
                form1.Show();
                form.Hide();
            }
            catch (HeightWidthException e)
            {
                MessageBox.Show(e.Message);
                return;
            }
        }

        private static void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
