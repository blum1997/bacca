﻿using System;
using System.Windows.Forms;
using System.Drawing;
using System.Threading;
using System.Collections.Generic;
using System.IO;
//using System.Runtime.InteropServices;
namespace MyGame
{
    static class Game
    {
        private delegate string writecons(string object1, string object2);

        private static BufferedGraphicsContext _context;
        public static BufferedGraphics Buffer;
        public static BaseObject[] _objs;//массив фигур      
        public static Player player;
        public static List<Shot> shots;
        public static List<Enemy> enemys;
        public static List<AidPack> AidPack;
        public static int Energy,Score;
        private static Font font;
        private static Point ptE;
        private static StreamWriter jour;
        // Свойства
        // Ширина и высота игрового поля
        public static int Width { get; set; }
        public static int Height { get; set; }
        static Game()
        {
        }
        public static void Init(Form form)
        {
            //журнал
            jour = new StreamWriter("jour.txt");
            // Графическое устройство для вывода графики
            Graphics g;
            Console.OpenStandardOutput();
            // предоставляет доступ к главному буферу графического контекста для текущего приложения
            _context = BufferedGraphicsManager.Current;
            g = form.CreateGraphics();// Создаём объект - поверхность рисования и связываем его с формой
                                      // Запоминаем размеры формы
            Width = form.Width;
            Height = form.Height;

            Load(); //создаем массив фигур и игрока

            // Связываем буфер в памяти с графическим объектом.
            // для того, чтобы рисовать в буфере
            Buffer = _context.Allocate(g, new Rectangle(0, 0, Width, Height));
            form.KeyPreview = true;
            form.KeyDown += Fon_KeyDown;
            form.Focus();


            System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer { Interval = 50 };
            timer.Start();
            timer.Tick += Timer_Tick;            System.Windows.Forms.Timer Reload = new System.Windows.Forms.Timer { Interval = 500 };
            Reload.Start();
            Reload.Tick += Reload_Tick;            System.Windows.Forms.Timer AidSpawn = new System.Windows.Forms.Timer { Interval = 10000 };
            AidSpawn.Start();
            AidSpawn.Tick += AidSpawn_Tick;            System.Windows.Forms.Timer Energy = new System.Windows.Forms.Timer { Interval = 1000 };
            Energy.Start();
            Energy.Tick += Energy_Tick;
        }


        public static void Load()
        {
           // AllocConsole();
            Energy = 100;
            Score = 0;
            font = new Font("Consolas", 10);
            ptE = new Point(50, 50);
            _objs = new BaseObject[25];
            int flag = 1;
            //загрузка красных планет
            Image img = Image.FromFile("planet1.png");
            for (int i = 0; i < 5; i++)
                _objs[i] = new ImageStar(new Point(100 * i, 20 + i * 90), new Point(7 * i + 10, 0), new Size(10, 10), img);

            //загрузка синих планет
            img = Image.FromFile("planet2.png");
            for (int i = 5; i < 8; i++)
                _objs[i] = new ImageStar(new Point(-800 + 250 * i, -700 + i * 150), new Point(i * 2, 0), new Size(10, 10), img);

            //загрузка звезд
            for (int i = 8; i < _objs.Length; i++)
            {
                _objs[i] = new Star(new Point(300 + 15 * i * flag, -210 + i * 30), new Point(10 + i * 3, 0), new Size(5, 5));
                flag = -flag;
            }

            //загрузка корабля игрока
            img = Image.FromFile("spaceship1.png");
            player = new Player(new Point(50, 200), img, 0, 0);

            //загрузка выстрелов
            shots = new List<Shot>();

            //загрузка противников
            enemys = new List<Enemy>();
            enemys.Add(new Enemy(new Point(800, 50), img));
            enemys.Add(new Enemy(new Point(600, 150), img));
            enemys.Add(new Enemy(new Point(450, 350), img));
            enemys.Add(new Enemy(new Point(700, 400), img));

            //загрузка аптечек
            AidPack = new List<AidPack>();
        }

        private static void Timer_Tick(object sender, EventArgs e)
        {
            Draw();
            Update();
        }

        public static void Draw()
        {
            //вывод на экран массива объектов
            Buffer.Graphics.Clear(Color.Black);
            foreach (BaseObject obj in _objs)
                obj.Draw();
            player.Draw();
            try
            {
                foreach (Shot sh in shots)
                {
                    if (sh.Needtodraw) sh.Draw();
                }
            }
            catch (System.InvalidOperationException)
            {
            }
            foreach (Enemy en in enemys)
            {
                if (en.Isalive) en.Draw();
            }
            try
            {
                foreach (AidPack ap in AidPack)
                {
                    if (ap.Needtodraw) ap.Draw();
                }
            }
            catch
            {
            }
            Game.Buffer.Graphics.DrawString($"Уровень энергии: {Convert.ToString(Energy)} Очки: {Convert.ToString(Score)}", font, Brushes.Yellow, ptE);
            Buffer.Render();
        }

        public static void Update()
        {
            foreach (BaseObject obj in _objs)
                obj.Update();
            foreach (Shot sh in shots)
            {
                if (sh.Needtoupdate) sh.Update();
                else { sh.Needtoupdate = false; sh.Dispose(); }
            }
            foreach (Enemy en in enemys)
            {
                if (en.Isalive) en.Update();
                else en.Dispose();
            }
            foreach (Shot sh in shots)
            {
                foreach (Enemy en in enemys)
                {
                    if (sh.Position.X + 10 > en.Position.X && sh.Position.X - 10 < en.Position.X && sh.Position.Y + 15 > en.Position.Y && sh.Position.Y - 35 < en.Position.Y)
                    { en.Isalive = false; sh.Needtodraw = false; sh.Needtoupdate = false; Score++; journal(enemyDead, "Player", "enemy"); }
                }
            }
            player.Update();
            foreach (AidPack ad in AidPack)
            {
                if (ad.Position.X + 10 > player.Position.X && ad.Position.X - 10 < player.Position.X && ad.Position.Y + 15 > player.Position.Y && ad.Position.Y - 35 < player.Position.Y)
                { ad.Needtodraw = false; ad.Needtoupdate = false; Energy = 100; journal(takeAid, "Player", "aid"); }
                else ad.Update();
            }
        }
        private static void Fon_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Down) player.MoveY = 10;
            if (e.KeyCode == Keys.Up) player.MoveY = -10;
            if (e.KeyCode == Keys.Left) player.MoveX = -10;
            if (e.KeyCode == Keys.Right) player.MoveX = +10;
            if (e.KeyCode == Keys.Space)
            {
                if (player.Reload == false)
                {
                    Image img = Image.FromFile("shot1.png");
                    Shot shot = new Shot(player.Position, img);
                    shots.Add(shot);
                    player.Reload = true;
                }
            }
        }
        private static void Reload_Tick(object sender, EventArgs e)
        {
            player.Reload = false;
        }
        private static void AidSpawn_Tick(object sender, EventArgs e)
        {
            Random rnd = new Random();
            Image img = Image.FromFile("AidPack.png");
            Point pt = new Point();
            pt.X = rnd.Next(200, 400);
            pt.Y = rnd.Next(150, 400);
            AidPack aid = new AidPack(pt, img);
            AidPack.Add(aid);
        }


        private static void Energy_Tick(object sender, EventArgs e)
        {
            Energy--;
        }


        //функция журналирования
        private static void journal(writecons func, string object1, string object2)
        {

            string message = func(object1, object2);
            jour.WriteLine(message,true);
        }

        private static string takeAid(string object1, string object2)
        {
            string result;
            result = $"{object1} took {object2}";
            return result;
        }

        private static string enemyDead(string object1, string object2)
        {
            string result;
            result = $"{object1} destroyed {object2}";
            return result;
        }

        //[DllImport("kernel32.dll", SetLastError = true)]
        //[return: MarshalAs(UnmanagedType.Bool)]
        //static extern bool AllocConsole();

        //[DllImport("kernel32.dll", SetLastError = true)]
        //[return: MarshalAs(UnmanagedType.Bool)]
        //static extern bool FreeConsole();
    }
}
