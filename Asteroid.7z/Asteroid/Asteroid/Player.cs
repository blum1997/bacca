﻿using System.Drawing;
namespace MyGame
{
    class Player
    {
        private Point Pos;
        private Image img;
        private bool Reloading;
        public Player(Point pos, Image img, int movex, int movey)
        {
            Pos = pos;    
            this.img = img;
            MoveX = movex;
            MoveY = movey;
        }

        public int MoveX;
        public int MoveY;

        public Point Position
        {
            set { }
            get { return this.Pos; }
        }

        public bool Reload { get => Reloading; set => Reloading = value; }

        public void Draw()
        {
            Game.Buffer.Graphics.DrawImage(img,Pos);
        }
        public void Update()
        {
            Pos.X = Pos.X + MoveX;
            Pos.Y = Pos.Y + MoveY;
            if (Pos.X < 0) Pos.X = 0;
            if (Pos.X > Game.Width) Pos.X = Game.Width;
            if (Pos.Y < 0) Pos.Y = 0;
            if (Pos.Y > Game.Height) Pos.X = Game.Height;
            MoveY = 0;
            MoveX = 0;
        }
    }
}