﻿using System;

namespace MyGame
{
    internal class GameObjectException : Exception
    {
        public GameObjectException()
        {
        }

        public GameObjectException(string message) : base(message)
        {
        }

        public GameObjectException(string message, Exception innerException) : base(message, innerException)
        {
        }

    }
}