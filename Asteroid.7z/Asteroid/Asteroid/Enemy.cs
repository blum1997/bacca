﻿using System.Drawing;
using System;
namespace MyGame
{
    class Enemy:IDisposable
    {
        private Point Pos;
        private Image img;
        private Random rnd;
        private bool IsAlive;

        public bool Isalive
        {
            get { return IsAlive; }
            set { IsAlive = value; }
        }

        public Enemy(Point pos, Image img)
        {
            Pos = pos;
            this.img = img;
            IsAlive = true;
            rnd = new Random();
        }

        public Point Position
        {
            set { }
            get { return this.Pos; }
        }

        public void Draw()
        {
            Game.Buffer.Graphics.DrawImage(img, Pos);
        }

        public void Update()
        {
            Pos.X = Pos.X - 20;
            Pos.Y = Pos.Y + rnd.Next(-10, 11);
            if (Pos.X < 0) Pos.X = Game.Width;//IsAlive = false;
            if (Pos.Y < 0) Pos.Y = 0;
            if (Pos.Y > Game.Height-50) Pos.Y = Game.Height-50;
        }

        public void Dispose()
        {
            img = null;
            Pos.X = 1200;
            Pos.Y = 1200;
            //GC.Collect();
        }
    }
}